// This file is deprecated - use useAuth from AuthContext instead
// Import directly from context: import { useAuth } from '../context/AuthContext'

export { useAuth as default } from "../context/AuthContext";
